using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private Transform cameraTransform; // Reference to the camera transform
    [SerializeField] private float speed = 5f; // Speed of the player movement
    [SerializeField] private float jumpHeight = 2f; // Force applied when the player jumps
    [SerializeField] private float gravity = -9.8f; // Gravity applied to the player
    [SerializeField] private bool shouldFaceMoveDirection = false; // Whether the player should face the direction of movement
    // private Animator animator; // Reference to the Animator component
    // private string currentAnimation = ""; // Current state of the animator
    private CharacterController controller; // Reference to the CharacterController component
    private Vector3 moveInput; // Input for player movement
    private Vector3 velocity; // Current velocity of the player
                              // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        controller = GetComponent<CharacterController>(); // Get the CharacterController component attached to the player
        if (controller == null)
        {
            Debug.LogError("CharacterController component is missing from the player object.");
        }
        // animator = GetComponent<Animator>(); // Get the Animator component attached to the player
        // if (animator == null)
        // {
        //     Debug.LogError("Animator component is missing from the player object.");
        // }
    }

    public void OnFire(InputAction.CallbackContext context)
    {
       if (context.performed)
        {
            Debug.Log("Fire!");
        }
    }
    
    public void OnMove(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>(); // Read the movement input from the player
                                                  //Debug.Log("Move Input: " + moveInput);
    }
    public void OnJump(InputAction.CallbackContext context)
    {
        if (context.performed && controller.isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity); // Calculate the jump velocity based on the jump height and gravity
                                                                 //Debug.Log("Jump!");
        }
    }
    // Update is called once per frame
    void Update()
    {
        Vector3 forward = cameraTransform.forward; // Get the forward direction of the camera
        Vector3 right = cameraTransform.right; // Get the right direction of the camera
        forward.y = 0; // Ignore vertical component for movement
        right.y = 0; // Ignore vertical component for movement
        forward.Normalize(); // Normalize the forward vector
        right.Normalize(); // Normalize the right vector
        Vector3 moveDirection = forward * moveInput.y + right * moveInput.x;
        controller.Move(moveDirection * speed * Time.deltaTime);
        if (shouldFaceMoveDirection && moveDirection.sqrMagnitude > 0.001f)
        {
            Quaternion toRotation = Quaternion.LookRotation(moveDirection, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, toRotation, 10f * Time.deltaTime);
        }
        velocity.y += gravity * Time.deltaTime; // Apply gravity to the player's velocity
        controller.Move(velocity * Time.deltaTime); // Apply the velocity to the player
        // CheckAnimation(); // Update the animation state based on movement and actions
    }
}


using UnityEngine;

public class ThirdPersonController : MonoBehaviour
{
    // [SerializeField] private float zoomSpeed = 5f;
    // [SerializeField] private float zoomLerpSpeed = 10f;
    // [SerializeField] private float minDistance = 3f;
    // [SerializeField] private float maxDistance = 15f;

    // private CinemachineCamera cam;
    // private CinemachineOrbitalFollow orbitalal;
    // private Vector2 scrollDelta;
    // private float targetZoom;
    // private float currentZoom;
    // void Start()
    // {
    //     controls = new PlayerControls();
    //     controls.Enable(); // Enable the input actions
    //     controls.CameraControls.MouseZoom.performed += HandleMouseScroll;
    //     Cursor.lockState = CursorLockMode.Locked;
    //     cam = GetComponent<CinemachineCamera>(); // Get the CinemachineCamera component attached to the player
    //     orbitalal = cam.GetComponent<CinemachineOrbitalFollow>(); // Get the CinemachineOrbitalFollower component
    //     targetZoom = currentZoom = orbitalal.Radius; // Initialize the target and current zoom to the camera's radius
    // }

    // private void HandleMouseScroll(InputAction.CallbackContext context)
    // {
    //     scrollDelta = context.ReadValue<Vector2>(); // Read the scroll input value
    //     Debug.Log("Scroll Delta: " + scrollDelta);
    // }
    // // Update is called once per frame
    // void Update()
    // {
    //     if (scrollDelta.y != 0)
    //     {
    //         if (orbitalal != null)
    //         {
    //             targetZoom = Mathf.Clamp(orbitalal.Radius - scrollDelta.y * zoomSpeed, minDistance, maxDistance);
    //             scrollDelta = Vector2.zero; // Reset scroll input after processing
    //         }
    //         float bumperdelta = controls.CameraControls.GamepadZoom.ReadValue<float>();
    //         if (bumperdelta != 0)
    //         {
    //             targetZoom = Mathf.Clamp(orbitalal.Radius - bumperdelta * zoomSpeed, minDistance, maxDistance);
    //         }
    //         currentZoom = Mathf.Lerp(currentZoom, targetZoom, Time.deltaTime * zoomLerpSpeed);
    //         orbitalal.Radius = currentZoom; // Update the camera's radius to the current zoom value
    //     }
    // }
}

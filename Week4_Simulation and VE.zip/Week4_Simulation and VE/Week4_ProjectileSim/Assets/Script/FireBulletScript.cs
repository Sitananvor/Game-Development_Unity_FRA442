using System.Collections;
using UnityEngine;

public class FireBulletScript : MonoBehaviour
{
    public GameObject bulletObject;
    public Transform bulletParent;
    // Start is called before the first frame update
    void Start()
    {
        //StartCoroutine(FireBullet());
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Create a new bullet
            GameObject newBullet = Instantiate(bulletObject, transform.position, transform.rotation);
            newBullet.transform.parent = bulletParent;
            newBullet.GetComponent<Rigidbody>().linearVelocity = BallisticScript.bulletSpeed * transform.forward;
        }
    }
    public IEnumerator FireBullet()
    {
        while (true)
        {
            GameObject newBullet = Instantiate(bulletObject, transform.position, transform.rotation);
            newBullet.transform.parent = bulletParent;
            newBullet.GetComponent<Rigidbody>().linearVelocity = BallisticScript.bulletSpeed * transform.forward;
        yield return new WaitForSeconds(2f);
        }
    }
}
using UnityEngine;
[RequireComponent(typeof(AudioSource))]

public class shipscript : MonoBehaviour
{
    float deathtimer;
    public float shipSpeed;
    public float screenBoundary;
    public GameObject shot;

    public alienfactoryscript alienfactory;

    private void OnTriggerEnter(Collider other)
    {
        if (GameStateScript.state == GameStateScript.GamePlay)
        {
            if (other.tag == "ashot")
            {
                scoringscript.lives--;
                deathtimer = 10.0f;
                GameStateScript.state = GameStateScript.Dying;
                if (scoringscript.lives == 0)
                {
                    Destroy(other.gameObject);
                    GameStateScript.state = GameStateScript.GameOver;
                }
            }
        }
    }

    void Start()
    {
        transform.position = new Vector3(0, -2.8f, 0);
    }

    void ShipControl()
    {
        if (Input.GetKey("right"))
            transform.Translate(shipSpeed * Time.deltaTime, 0, 0);

        if (Input.GetKey("left"))
            transform.Translate(-shipSpeed * Time.deltaTime, 0, 0);

        // ล็อคไม่ให้ออกนอกขอบจอ
        if (transform.position.x < -screenBoundary)
            transform.position = new Vector3(-screenBoundary, transform.position.y, transform.position.z);
        if (transform.position.x > screenBoundary)
            transform.position = new Vector3(screenBoundary, transform.position.y, transform.position.z);

        // ยิงกระสุน
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(
                shot,
                new Vector3(transform.position.x, transform.position.y, 0.5f),
                Quaternion.identity
            );
            GetComponent<AudioSource>().Play();
        }
    }

    // 2) สร้าง Update() ใหม่ “ไว้ใต้ ShipControl()” เพื่อจัดการสถานะเกม (FSM)
    void Update()
    {
        // เล่นจริง → ค่อยควบคุมเรือ
        if (GameStateScript.state == GameStateScript.GamePlay)
            ShipControl();

        // เพิ่งเริ่มเล่น → สร้างศัตรูแล้วสลับไป GamePlay
        if (GameStateScript.state == GameStateScript.StartingPlay)
        {
            if (alienfactory != null)
                alienfactory.MakeAliens();

            GameStateScript.state = GameStateScript.GamePlay;
        }

        // ลูปตอน Dying (sequence ตอนตาย)
        if (GameStateScript.state == GameStateScript.Dying)
        {
            transform.Rotate(0, 0, Time.deltaTime * 400.0f);
            deathtimer -= 0.1f;

            if (deathtimer < 5.0f)
                GetComponent<Renderer>().enabled = false;

            if (deathtimer < 0)
            {
                GameStateScript.state = GameStateScript.GamePlay;
                transform.position = new Vector3(0.0f, transform.position.y, 0.0f);
                transform.rotation = Quaternion.identity;
                GetComponent<Renderer>().enabled = true;

                if (scoringscript.lives == 0)
                    GameStateScript.state = GameStateScript.GameOver;
            }
        }

        // เช็คเปลี่ยนด่าน (กันบั๊กยิงตัวสุดท้ายแล้วตายพร้อมกัน)
        if (GameStateScript.state == GameStateScript.GamePlay)
        {
            if (scoringscript.aliencounter == 0)
            {
                GameStateScript.state = GameStateScript.StartingPlay;
                scoringscript.level++;
            }
        }
    }

}

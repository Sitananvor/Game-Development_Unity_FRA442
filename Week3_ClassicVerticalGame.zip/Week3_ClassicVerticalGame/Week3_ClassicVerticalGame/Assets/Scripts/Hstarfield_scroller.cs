using UnityEngine;

public class Hstarfield_scroller : MonoBehaviour
{
    public float scrollspeed;
    void Update()
    {
        transform.Translate(scrollspeed * Time.deltaTime, 0, 0);
        if (transform.position.x < -13f)   
        {
            transform.Translate(30.72f, 0, 0);
        }
    }
}

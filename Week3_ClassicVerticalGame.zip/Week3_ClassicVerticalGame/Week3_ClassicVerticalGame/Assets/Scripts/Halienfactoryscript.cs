using UnityEngine;

public class Halienfactoryscript : MonoBehaviour
{
    public GameObject alien;

    int[] colsByLevel = { 2, 3, 4, 6 };
    int[] rowsByLevel = { 5, 8, 10, 13 };

    public void MakeAliens()
    {
        Hscoringscript.aliencounter = 0;
        int cols = colsByLevel[Hscoringscript.level];
        int rows = rowsByLevel[Hscoringscript.level];

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
            {
                Hscoringscript.aliencounter++;
                GameObject al = Instantiate(
                alien,
                new Vector3((i - 5) * 0.5f - 3f, (j - 1) * 0.8f , 0),
                Quaternion.identity);
                al.GetComponent<Halienscript>().state = 0;
            }
    }

    // Start is called before the first frame update
    void Start()
    {
        // MakeAliens();
    }

}

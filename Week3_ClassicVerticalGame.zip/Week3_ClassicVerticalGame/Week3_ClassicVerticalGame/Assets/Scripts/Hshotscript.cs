using UnityEngine;

public class Hshotscript : MonoBehaviour
{
    public float shotSpeed;

    // Update is called once per frame
    void Update()
    {
        transform.Translate(0, shotSpeed * Time.deltaTime, 0);
        if (transform.position.y > 16.0f)
            Destroy(gameObject);
    }
}

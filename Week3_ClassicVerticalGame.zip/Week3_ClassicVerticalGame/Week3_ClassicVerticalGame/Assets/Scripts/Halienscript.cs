using UnityEngine;

public class Halienscript : MonoBehaviour
{
    public GameObject ashot;

    public int state;
    public float timer;

    int[] levelarr = { 50, 30, 20, 10 };

    //motion of alien
    public float moveSpeed = 1.0f;

    void Start()
    {
        state = 0;
    }

    // Update is called once per frame
    void Update()
    {
        int levindex;
        levindex = Hscoringscript.level - 1;
        if (levindex > 3) levindex = 3;
        if (levindex < 0) levindex = 0;

        if (HGameStateScript.state == HGameStateScript.GamePlay)
            if (Mathf.FloorToInt(Random.value * 10000.0f) % (levelarr[levindex] * Hscoringscript.aliencounter * 10000) == 0)
            {
                Instantiate(
                ashot,
                new Vector3(transform.position.x, transform.position.y, 0.5f),
                Quaternion.Euler(0, 0, 90));
                gameObject.GetComponent<AudioSource>().Play();

            }
        AlienMovement();

        // if it’s dying go through the death sequence
        if (state == 1)
        {
            transform.Rotate(0, 0, Time.deltaTime * 400.0f);
            transform.Translate(0.3f * Time.deltaTime, -3.0f * Time.deltaTime, 0, Space.World);
            transform.localScale = transform.localScale * 0.99f;
            timer -= 0.1f;
            if (timer < 0.0f)
            {
                Destroy(gameObject);
                Hscoringscript.aliencounter--;
            }
        }

        if (HGameStateScript.state == HGameStateScript.PressStart)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "shot")
        {
            Hscoringscript.score += 10;
            state = 1;
            timer = 5.0f;
            Destroy(other.gameObject);
        }
    }

    //motion of alien
    private void AlienMovement()
    {
        // เคลื่อนที่ลงด้านล่างอย่างต่อเนื่อง
        transform.Translate(0, -moveSpeed * Time.deltaTime, 0);

        // ถ้าลงถึงขอบที่กำหนดแล้ว ให้เคลื่อนที่กลับขึ้นไปบนถึงขอบที่กำหนด
        if (transform.position.y <= -3)
        {
            transform.position = new Vector3(transform.position.x, 3f, transform.position.z);  //ขึ้นไป
        }
    }
}

using UnityEngine;
[RequireComponent(typeof(AudioSource))]
public class Hshipscript : MonoBehaviour
{
    //ยาน
    public float shipSpeed;
    public float screenBoundary;

    //ยิงกระสุน   
    public GameObject shot;

    //สร้างเอเลี่ยน
    public Halienfactoryscript alienfactory;

    //ชีวิต
    float deathtimer;

    void ShipControl()
    {
        //เคลื่อนที่ยาน
        if (Input.GetKey("up"))
        {
            transform.Translate(shipSpeed * Time.deltaTime, 0, 0);  //ยานถูกหมุน (เช่น Z = 90°) แกน local Y ชี้ไปทาง world X
        }
        if (Input.GetKey("down"))
        {
            transform.Translate(-shipSpeed * Time.deltaTime, 0, 0); //ยานถูกหมุน (เช่น Z = 90°) แกน local Y ชี้ไปทาง world X
        }
        if (transform.position.y < -screenBoundary)
            transform.position = new Vector3(transform.position.x, -screenBoundary, transform.position.z);
        if (transform.position.y > screenBoundary)
            transform.position = new Vector3(transform.position.x, screenBoundary, transform.position.z);

        //ยิงกระสุน
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(    //clone prefab ขึ้นมาใน Scene
            shot,           //prefab ที่จะ clone
            new Vector3(transform.position.x, transform.position.y, 0.5f),  //วางกระสุนตรงตำแหน่งของยาน (x,y เดียวกัน) แต่ใส่ z=0.5 ให้อยู่ “ลอยออกมา” นิดหน่อย
            Quaternion.Euler(0, 0, 90)   // หมุนซ้าย
            );
            gameObject.GetComponent<AudioSource>().Play();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (HGameStateScript.state == HGameStateScript.GamePlay)
        {
            if (other.tag == "ashot")
            {
                Hscoringscript.lives--;
                deathtimer = 10.0f;
                HGameStateScript.state = HGameStateScript.Dying;
                if (Hscoringscript.lives == 0)
                {
                    Destroy(other.gameObject);
                    HGameStateScript.state = HGameStateScript.GameOver;
                }
            }
        }
    }
    void Start()
    {
        transform.position = new Vector3(6.2f, 0, 0);   //ตั้งตำแหน่งเริ่มต้นของยาน
    }

    void Update()
    {
        if (HGameStateScript.state == HGameStateScript.GamePlay)
        {
            ShipControl();
            if (Hscoringscript.aliencounter == 0)
            {
                HGameStateScript.state = HGameStateScript.StartingPlay;
                Hscoringscript.level++;
            }
        }

        if (HGameStateScript.state == HGameStateScript.StartingPlay)
        {
            alienfactory.MakeAliens();
            HGameStateScript.state = HGameStateScript.GamePlay;
        }

        if (HGameStateScript.state == HGameStateScript.Dying)
        {
            transform.Rotate(0, 0, Time.deltaTime * 400.0f);
            deathtimer -= 0.1f;
            if (deathtimer < 5.0f)
            {
                GetComponent<Renderer>().enabled = false;       //ทำให้ยานหายไป
            }
            if (deathtimer < 0)
            {
                HGameStateScript.state = HGameStateScript.GamePlay;
                transform.position = new Vector3(transform.position.x, 0.0f, 0.0f);
                transform.rotation = Quaternion.Euler(0, 0, 90);
                GetComponent<Renderer>().enabled = true;        //ทำให้ยานกลับมา
                if (Hscoringscript.lives == 0)
                {
                    HGameStateScript.state = HGameStateScript.GameOver;
                }
            }
        }
    }
}

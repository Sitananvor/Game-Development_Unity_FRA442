using UnityEngine;

public class Hashotscript : MonoBehaviour
{
    public float ashotSpeed;
    
    // Update is called once per frame
    void Update()
    {
        transform.Translate(0, ashotSpeed * Time.deltaTime, 0);
        if (transform.position.y < -16)
            Destroy(gameObject);
    }
}

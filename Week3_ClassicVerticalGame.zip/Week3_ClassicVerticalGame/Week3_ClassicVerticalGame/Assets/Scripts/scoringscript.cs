using UnityEngine;

public class scoringscript : MonoBehaviour
{
    public static int score;
    public static int lives;
    public static int level;
    public static int aliencounter;

    void InitializeGame()
    {
        score = 0;
        lives = 3;
        level = 0;
    }
    // Start is called before the first frame update
    void Start()
    {
        InitializeGame();
    }
    private void OnGUI()
    {
        GUI.Box(new Rect(10, 10, 100, 30), "Score: " + score);
        GUI.Box(new Rect(Screen.width - 110, 10, 100, 30), "Lives: " + lives);

        if (GameStateScript.state == GameStateScript.PressStart)
        {
            if (GUI.Button(new Rect(Screen.width / 2 - 150, Screen.height / 2 - 50, 300, 50), "Click Me to Start"))
            {
                GameStateScript.state = GameStateScript.StartingPlay;
            }
        }

        if (GameStateScript.state == GameStateScript.GameOver)
        {
            if (GUI.Button(new Rect(Screen.width / 2 - 200, Screen.height / 2 - 50, 400, 50), "Game Over, Try again"))
            {
                InitializeGame();
                GameStateScript.state = GameStateScript.PressStart;
            }
        }

        // for debugging
        GUI.Box(new Rect(Screen.width / 2 - 60, 10, 120, 30), "State: " + GameStateScript.state);
        GUI.Box(new Rect(Screen.width / 2 - 60, 30, 120, 30), "Aliencounter: " + scoringscript.aliencounter);
        GUI.Box(new Rect(Screen.width / 2 - 60, 50, 120, 30), "Level: " + scoringscript.level);

    }
}

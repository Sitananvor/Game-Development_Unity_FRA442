using UnityEngine;

public class alienscript : MonoBehaviour
{
    public GameObject ashot;
    public int state;
    public float timer;
    int[] levelarr = { 50, 30, 20, 10 };

    void Start()
    {
        state = 0;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "shot")
        {
            scoringscript.score += 10;
            state = 1;
            timer = 5.0f;
            Destroy(other.gameObject);
        }
    }

    void Update()
    {
        int levindex;
        levindex = scoringscript.level - 1;
        if (levindex > 3) levindex = 3;
        if (levindex < 0) levindex = 0;
        
        if (GameStateScript.state == GameStateScript.GamePlay)
            if (Mathf.FloorToInt(Random.value * 10000.0f) % (levelarr[levindex] * scoringscript.aliencounter * 10000) == 0)
            {
                Instantiate(
                ashot,
                new Vector3(transform.position.x, transform.position.y, 0.5f),
                Quaternion.identity);
                gameObject.GetComponent<AudioSource>().Play();
            }

        // if it’s dying go through the death sequence
        if (state == 1)
        {
            transform.Rotate(0, 0, Time.deltaTime * 400.0f);
            transform.Translate(0.3f * Time.deltaTime, 3.0f * Time.deltaTime, 0, Space.World);
            transform.localScale = transform.localScale * 0.99f;
            timer -= 0.1f;
            if (timer < 0.0f)
            {
                Destroy(gameObject);
                scoringscript.aliencounter--;
            }
            if (scoringscript.aliencounter == 0)
            {
                GameStateScript.state = GameStateScript.StartingPlay;
                scoringscript.level++;
            }
        }

        if (GameStateScript.state == GameStateScript.PressStart)
        {
            Destroy(gameObject);
        }


    }
}


using UnityEngine;

public class shotscript : MonoBehaviour
{
    public float shotSpeed;
    // Start is called before the first frame update
    void Start()
    { }
    // Update is called once per frame
    void Update()
    {
        transform.Translate(0, shotSpeed * Time.deltaTime, 0);
        if (transform.position.y > 6.0f)
            Destroy(gameObject);
    }

}

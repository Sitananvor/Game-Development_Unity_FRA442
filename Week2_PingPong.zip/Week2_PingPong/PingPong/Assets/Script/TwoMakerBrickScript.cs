using UnityEngine;

public class TwoMakerBrickScript : MonoBehaviour
{
    public Vector3 originP1 = new Vector3(-15f, 0f, 0f); // จุดเริ่ม 'มุมซ้ายบน' ของกำแพง P1
    public Vector3 originP2 = new Vector3(15f, 0f, 0f); // จุดเริ่ม 'มุมซ้ายบน' ของกำแพง P2

    void Start()
    {
        BuildWall(originP1, "Bricks_P1", 1);
        BuildWall(originP2, "Bricks_P2", 2);
    }


    void BuildWall(Vector3 origin, string parentName, int ownerId)
    {
        // parent = จุดยึดเริ่มต้นของกำแพง (มุมซ้ายบน)
        var parent = new GameObject(parentName).transform;
        parent.position = origin;

        for (int y = 0; y < 8; y++)
            for (int x = 0; x < 13; x++)
            {
                var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cube.transform.SetParent(parent, false);              // ใช้ local space
                cube.transform.localPosition = new Vector3(x * 2 - 12, y - 1, 0f); // เดินจากมุมซ้ายบน
                cube.transform.localScale = new Vector3(1.9f, 0.9f, 1);

                var b = cube.AddComponent<TwoBrickScript>();
                b.ownerId = ownerId;

                var renderer = cube.GetComponent<Renderer>();
                renderer.material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
                if (y < 2) renderer.material.color = Color.yellow;
                else if (y < 4) renderer.material.color = Color.cyan;
                else if (y < 6) renderer.material.color = Color.blue;
                else renderer.material.color = Color.red;

                cube.GetComponent<Collider>().isTrigger = true;
            }
    }
}

using UnityEngine;

public class TwoWallTopScript : MonoBehaviour
{
        private void OnTriggerEnter(Collider other)
    {
        TwoBallScript ball = other.GetComponent<TwoBallScript>();
        if (ball != null)
        {
            if (ball.Id == 1)
            {
                // ถ้าเป็นบอลของ player 1 → กำหนดเร่งแบบที่ 1
                ball.yspeed = -ball.yspeed * 1.2f;  // ยกตัวอย่าง คูณความเร็วเพิ่ม 20%
                ball.collflag = true;
            }
            else if (ball.Id == 2)
            {
                // ถ้าเป็นบอลของ player 2 → กำหนดเร่งแบบที่ 2
                ball.yspeed = -ball.yspeed * 1.2f;  // ลดความเร็วลง 20%
                ball.collflag = true;
            }
        }
    }
}

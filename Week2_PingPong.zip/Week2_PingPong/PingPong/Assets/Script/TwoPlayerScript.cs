using UnityEngine;

public class TwoPlayerScript : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        TwoBallScript ball = other.GetComponent<TwoBallScript>();

        // เด้งแกน Y ของลูกนั้น
        ball.yspeed = -ball.yspeed;

        // ถ้าบอลเข้าทางขวาของไม้ → ให้ความเร็ว X เป็นบวก, ถ้าเข้าทางซ้าย → ให้เป็นลบ
        float dirX = (other.transform.position.x > transform.position.x) ? 1f : -1f;
        ball.xspeed = Mathf.Abs(ball.xspeed) * dirX;

        // ตั้งธงชนเฉพาะลูกนี้
        ball.collflag = true;
    }
}

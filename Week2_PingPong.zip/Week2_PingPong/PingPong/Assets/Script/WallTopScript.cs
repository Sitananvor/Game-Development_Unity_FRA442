using UnityEngine;

public class WallTopScript : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
    BallBrickk.yspeed = -BallBrickk.yspeed;
    BallBrickk.collflag = true;
    }
}

using UnityEngine;

public class TwoBrickScript : MonoBehaviour
{
    // เจ้าของกำแพงนี้ (1 = P1, 2 = P2)
    public int ownerId = 1;

    private void OnTriggerEnter(Collider other)
    {
        // ต้องเป็นบอลเท่านั้น
        var ball = other.GetComponent<TwoBallScript>();
        // ถ้าเป็นบอลฝั่งตรงข้าม -> ทำลาย + เพิ่มคะแนน
        if (ball.collflag)
        {
            ball.yspeed = -ball.yspeed;
            ball.collflag = false;

            if (ball.Id == 1)
                TwoScore.scoreP1 += 10;
            else
                TwoScore.scoreP2 += 10;

            Destroy(gameObject);
        }
    }
}

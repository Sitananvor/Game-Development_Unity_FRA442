using UnityEngine;
using UnityEngine.SceneManagement;

public class BallBriickRelaunch : MonoBehaviour
{
        private void OnTriggerEnter(Collider other)
    {
        other.transform.position = new Vector3(0, -7, 0);
        BallBrickk.xspeed = 8.0f;
        BallBrickk.yspeed = -8.0f;
        BallBrickk.launchtimer = 1.0f;
        ScoringBrick.lives--;
        if (ScoringBrick.lives == 0)
        {
            SceneManager.LoadScene("StartBrick2Players");
        }
    }
}

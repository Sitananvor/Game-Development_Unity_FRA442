using UnityEngine;
[RequireComponent(typeof(AudioSource))]
public class BallBrick : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Rigidbody rigidb = GetComponent<Rigidbody>();
        if (rigidb)
        {
            rigidb.freezeRotation = true;
        }
        rigidb.AddForce(Random.Range(6, 8), Random.Range(-4, -3), 0);
        StartCoroutine("Waitforit");
    }

    // Update is called once per frame
    void Update()
    {
    }

    private void OnCollisionEnter(Collision collision)
    {
        AudioSource audio = GetComponent<AudioSource>();
        audio.Play();
    }
}

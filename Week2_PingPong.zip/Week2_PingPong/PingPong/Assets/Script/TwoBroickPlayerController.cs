using UnityEngine;
using UnityEngine.InputSystem;

public class TwoBroickPlayerController : MonoBehaviour
{
    private CharacterController controller;
    private Vector2 moveInput;
    // Start is called once before the first execution of Update after the MonoBehaviour is creat
    void Start()
    {
        controller = GetComponent<CharacterController>();
        if (controller == null)
        {
            Debug.LogError("CharacterController component is missing from the GameObject.");
        }
    }
    public void OnMove(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>();
        Debug.Log("Move Input: " + moveInput);
    }
    // Update is called once per frame
    void Update()
    {
        Vector3 move = new Vector3(moveInput.x, 0, 0);
        controller.Move(move * 20 * Time.deltaTime);
    }
}

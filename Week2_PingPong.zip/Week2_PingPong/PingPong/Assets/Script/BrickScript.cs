using UnityEngine;

public class BrickScript : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
    if (BallBrickk.collflag == true)
    {
    BallBrickk.yspeed = -BallBrickk.yspeed;
    BallBrickk.collflag = false;
    Destroy(gameObject);
    ScoringBrick.score += 10;
    }
    }
}

using UnityEngine;

public class TwoScore : MonoBehaviour
{
        public static int scoreP1, scoreP2;
        public static int livesP1, livesP2;
        // Start is called before the first frame update
        void Start()
        {
            scoreP1 = 0; scoreP2 = 0;
            livesP1 = 3;  livesP2 = 3;
        }
        private void OnGUI()
        {
            GUI.Box(new Rect(10, 10, 110, 55), "Player1: " + "\n" + "Score: " + scoreP1 + "\n" +  "Lives: " + livesP1);
            GUI.Box(new Rect(Screen.width - 90, 10, 110, 55), "Player2: " + "\n" + "Score: " + scoreP2 + "\n" +  "Lives: " + livesP2);
        }
}

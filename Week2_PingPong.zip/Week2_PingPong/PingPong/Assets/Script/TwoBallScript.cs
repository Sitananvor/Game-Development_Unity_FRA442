using UnityEngine;
[RequireComponent(typeof(AudioSource))]
public class TwoBallScript : MonoBehaviour
{
    public int Id = 1;
    public float launchtimer;
    public float xspeed;
    public float yspeed;
    public bool collflag; 
    // Start is called before the first frame update
    void Start()
    {
        launchtimer = 2.0f;
        xspeed = 8.0f;
        yspeed = 8.0f;
        collflag = true;
    }
    // Update is called once per frame
    void Update()
    {
        launchtimer -= Time.deltaTime;
        if (launchtimer <= 0.0f)
        {
            transform.Translate(
            new Vector3(
            xspeed * Time.deltaTime,
            yspeed * Time.deltaTime,
            0));
            launchtimer = 0.0f;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        AudioSource audio = GetComponent<AudioSource>();
        audio.Play();
    }
}
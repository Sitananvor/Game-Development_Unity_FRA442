using UnityEngine;
using UnityEngine.SceneManagement;

public class EndBrickGamefor2PlayersTitle : MonoBehaviour
{
 public Texture BackgroundTexture;
    private void OnGUI()
    {
        GUI.DrawTexture(
            new Rect(
                0,
                0,
                Screen.width,
                Screen.height),
                BackgroundTexture);
    }
}

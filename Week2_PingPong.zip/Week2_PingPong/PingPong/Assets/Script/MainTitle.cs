using UnityEngine;
using UnityEngine.SceneManagement;

public class MainTitle : MonoBehaviour
{
    public Texture BackgroundTexture;
    private void OnGUI()
    {
        GUI.DrawTexture(
            new Rect(
                0,
                0,
                Screen.width,
                Screen.height),
                BackgroundTexture);
                
        if (Input.anyKeyDown)
        {
            Debug.Log("A key or mouse click has been detected");
            SceneManager.LoadScene("BrickScene");
        }
    }
}
using UnityEngine;

public class WallScript : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        BallBrickk.xspeed = -BallBrickk.xspeed;
        BallBrickk.collflag = true;
    }
}

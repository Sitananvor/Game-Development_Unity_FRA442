using UnityEngine;
using UnityEngine.SceneManagement;

public class TwoBallRelaunch : MonoBehaviour
{
    // จุดเกิดใหม่ของแต่ละผู้เล่น (ปรับตามฉากของคุณ)
    public Vector3 respawnP1 = new Vector3(-15f, -7f, 0f);
    public Vector3 respawnP2 = new Vector3(15f, -7f, 0f);

    private void OnTriggerEnter(Collider other)
    {
        // ต้องเป็นบอลเท่านั้น
        var ball = other.GetComponent<TwoBallScript>();
        if (ball == null) return;

        // เลือกจุดเกิดใหม่ตามผู้เล่น
        Vector3 respawnPos = (ball.Id == 1) ? respawnP1 : respawnP2;

        // รีเซ็ต “เฉพาะบอลลูกนี้”
        ball.transform.position = respawnPos;
        ball.xspeed = 8.0f;
        ball.yspeed = -8.0f;
        ball.launchtimer = 1.0f;

        // หักชีวิตเฉพาะผู้เล่นของบอลลูกนี้
        if (ball.Id == 1)
        {
            TwoScore.livesP1--;
        }
        else if (ball.Id == 2)
        {
            TwoScore.livesP2--;
        }

        // เงื่อนไขจบเกม (ตัวอย่าง: ใครก็ตามชีวิตหมด)
        if (TwoScore.livesP1 == 0 || TwoScore.livesP2 == 0)
        {
            SceneManager.LoadScene("EndBrick2Players");
        }
    }
}

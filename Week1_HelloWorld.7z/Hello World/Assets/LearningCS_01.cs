using System;
using UnityEngine;
public class LearningCS_01 : MonoBehaviour
{
 private int currentAge = 30;
 public int addedAge = 1;
 public string firstName = "FRA442";
 public bool isStudent = true;
 // Start is called before the first frame update
 void Start()
 {
 ComputeAge();
 Debug.Log($"A string can have variables like {firstName} inserted directly!");
 }
 // Update is called once per frame
 void Update()
 {

 }
 void ComputeAge()
 {
 Debug.Log(currentAge + addedAge);
 }
}
using UnityEngine;

public class Testing123 : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnGUI()
    {
        int result = 2 + 2;
        GUI.Box(new Rect(10, 10, 300, 40), "Result 2+2 is " + result + "\n" + "Sitanan Voraritruangurai");
    }
}
